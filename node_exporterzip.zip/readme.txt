Save this to a file node_exporter.service.j2 in the same directory as your playbook
